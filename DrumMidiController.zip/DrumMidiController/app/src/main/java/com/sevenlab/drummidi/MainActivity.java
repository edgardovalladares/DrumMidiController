package com.sevenlab.drummidi;

import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.media.midi.*;
import android.os.*;
import android.view.*;
import android.widget.Toast;

import java.io.IOException;
import java.util.*;

public class MainActivity extends Activity {
    private SoundPool soundPool;
    private final Map<Integer, Integer> soundMap = new HashMap<>();
    private MidiSender midiSender;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(12).setAudioAttributes(attrs).build();

        soundMap.put(36, soundPool.load(this, R.raw.kick, 1));
        soundMap.put(38, soundPool.load(this, R.raw.snare, 1));
        soundMap.put(45, soundPool.load(this, R.raw.tom_low, 1));
        soundMap.put(47, soundPool.load(this, R.raw.tom_mid, 1));
        soundMap.put(50, soundPool.load(this, R.raw.tom_high, 1));
        soundMap.put(41, soundPool.load(this, R.raw.floor, 1));
        soundMap.put(42, soundPool.load(this, R.raw.hihat_closed, 1));
        soundMap.put(46, soundPool.load(this, R.raw.hihat_open, 1));
        soundMap.put(49, soundPool.load(this, R.raw.crash, 1));
        soundMap.put(51, soundPool.load(this, R.raw.ride, 1));
        soundMap.put(55, soundPool.load(this, R.raw.splash, 1));

        midiSender = new MidiSender(this);
        midiSender.openAllInputs();
        setContentView(new DrumKitView(this, this::triggerPad));
    }

    private void triggerPad(Pad pad, float pressure) {
        int soundId = soundMap.containsKey(pad.note) ? soundMap.get(pad.note) : 0;
        float vol = Math.min(1f, 0.55f + pressure * 0.55f);
        if (soundId != 0) soundPool.play(soundId, vol, vol, 1, 0, 1f);
        midiSender.sendNote(pad.note, Math.max(40, Math.min(127, (int)(pressure * 127))));
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (soundPool != null) soundPool.release();
        if (midiSender != null) midiSender.close();
    }

    interface PadListener { void onHit(Pad pad, float pressure); }

    static class Pad {
        String label; int note; RectF rect; boolean cymbal; long lastHit;
        Pad(String label, int note, RectF rect, boolean cymbal) { this.label = label; this.note = note; this.rect = rect; this.cymbal = cymbal; }
        boolean contains(float x, float y) { return rect.contains(x, y); }
    }

    static class DrumKitView extends View {
        private final ArrayList<Pad> pads = new ArrayList<>();
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final PadListener listener;
        private final Handler handler = new Handler(Looper.getMainLooper());

        DrumKitView(Context ctx, PadListener listener) {
            super(ctx); this.listener = listener;
            setBackgroundColor(Color.rgb(8, 9, 10));
            setFocusable(true);
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) { layoutPads(w, h); }

        private void layoutPads(int w, int h) {
            pads.clear();
            float u = Math.min(w, h) / 10f;
            pads.add(new Pad("CRASH", 49, oval(w*.06f, h*.02f, u*1.25f), true));
            pads.add(new Pad("SPLASH",55, oval(w*.36f, h*.03f, u*.85f), true));
            pads.add(new Pad("CRASH", 49, oval(w*.60f, h*.02f, u*1.05f), true));
            pads.add(new Pad("RIDE",  51, oval(w*.82f, h*.03f, u*1.30f), true));
            pads.add(new Pad("CLOSED HH",42, oval(w*.86f, h*.34f, u*.92f), true));
            pads.add(new Pad("OPEN HH",46, oval(w*.91f, h*.58f, u*.92f), true));
            pads.add(new Pad("FLOOR",41, oval(w*.04f, h*.52f, u*1.15f), false));
            pads.add(new Pad("TOM",47, oval(w*.30f, h*.34f, u*.92f), false));
            pads.add(new Pad("TOM",50, oval(w*.49f, h*.26f, u*.92f), false));
            pads.add(new Pad("TOM",45, oval(w*.68f, h*.34f, u*.92f), false));
            pads.add(new Pad("KICK",36, oval(w*.28f, h*.63f, u*1.65f), false));
            pads.add(new Pad("KICK",36, oval(w*.62f, h*.63f, u*1.65f), false));
            pads.add(new Pad("SNARE",38, oval(w*.50f, h*.52f, u*1.15f), false));
        }
        private RectF oval(float cx, float cy, float r) { return new RectF(cx-r, cy-r*.68f, cx+r, cy+r*.68f); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            drawBg(c);
            for (Pad pad : pads) drawPad(c, pad);
            drawFooter(c);
        }
        private void drawBg(Canvas c) {
            p.setStrokeWidth(2); p.setColor(Color.rgb(20,22,24));
            for (int i=-getHeight(); i<getWidth(); i+=36) c.drawLine(i, getHeight(), i+getHeight(), 0, p);
        }
        private void drawPad(Canvas c, Pad pad) {
            long age = SystemClock.uptimeMillis() - pad.lastHit;
            boolean active = age < 90;
            RectF r = pad.rect;
            p.setStyle(Paint.Style.FILL);
            if (pad.cymbal) {
                RadialGradient g = new RadialGradient(r.centerX(), r.centerY(), r.width()/2,
                        active ? Color.rgb(255,245,205) : Color.rgb(240,170,92),
                        Color.rgb(158,83,40), Shader.TileMode.CLAMP);
                p.setShader(g); c.drawOval(r, p); p.setShader(null);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(12); p.setColor(active ? Color.rgb(255,220,80) : Color.rgb(210,105,70)); c.drawOval(r, p);
                p.setStrokeWidth(0);
            } else {
                p.setColor(Color.rgb(52,52,45)); c.drawOval(r, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(12); p.setColor(active ? Color.rgb(0,190,205) : Color.rgb(13,124,134)); c.drawOval(r, p);
                p.setStrokeWidth(4); p.setColor(Color.rgb(190,160,125)); c.drawOval(r, p);
                if (pad.label.equals("KICK")) { p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(225,228,226)); c.drawCircle(r.centerX(), r.centerY(), r.height()*0.27f, p); }
            }
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
            p.setTextSize(Math.max(22, r.width()*0.11f)); p.setColor(pad.cymbal ? Color.rgb(35,35,30) : Color.rgb(210,245,245));
            c.save(); c.rotate(pad.cymbal ? 12 : 0, r.centerX(), r.centerY()); c.drawText(pad.label, r.centerX(), r.centerY()+p.getTextSize()/3, p); c.restore();
        }
        private void drawFooter(Canvas c) {
            p.setTextAlign(Paint.Align.LEFT); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT_BOLD); p.setColor(Color.argb(190,255,255,255));
            c.drawText("Drum MIDI Controller · Toca cada pad · MIDI notes GM", 24, getHeight()-28, p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) hit(e, e.getActionIndex());
            return true;
        }
        private void hit(MotionEvent e, int index) {
            float x=e.getX(index), y=e.getY(index), pressure=Math.max(.35f, e.getPressure(index));
            for (int i=pads.size()-1; i>=0; i--) {
                Pad pad=pads.get(i);
                if (pad.contains(x,y)) { pad.lastHit = SystemClock.uptimeMillis(); listener.onHit(pad, pressure); invalidate(); handler.postDelayed(this::invalidate, 110); performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); break; }
            }
        }
    }

    static class MidiSender {
        private final Context context; private final Handler handler = new Handler(Looper.getMainLooper());
        private final ArrayList<MidiInputPort> ports = new ArrayList<>(); private final ArrayList<MidiDevice> devices = new ArrayList<>();
        MidiSender(Context context) { this.context = context; }
        void openAllInputs() {
            if (Build.VERSION.SDK_INT < 23) return;
            MidiManager mm = (MidiManager) context.getSystemService(Context.MIDI_SERVICE);
            if (mm == null) return;
            for (MidiDeviceInfo info : mm.getDevices()) {
                for (MidiDeviceInfo.PortInfo pi : info.getPorts()) if (pi.getType() == MidiDeviceInfo.PortInfo.TYPE_INPUT) {
                    mm.openDevice(info, device -> { if (device != null) { devices.add(device); MidiInputPort port = device.openInputPort(pi.getPortNumber()); if (port != null) ports.add(port); } }, handler);
                }
            }
        }
        void sendNote(int note, int velocity) {
            if (ports.isEmpty()) return;
            byte[] on = new byte[]{(byte)0x99, (byte)note, (byte)velocity}; // Channel 10
            byte[] off = new byte[]{(byte)0x89, (byte)note, 0};
            long now = System.nanoTime();
            for (MidiInputPort port: ports) try { port.send(on,0,on.length,now); } catch(IOException ignored) {}
            handler.postDelayed(() -> { for (MidiInputPort port: ports) try { port.send(off,0,off.length,System.nanoTime()); } catch(IOException ignored) {} }, 90);
        }
        void close() { for (MidiInputPort p: ports) try { p.close(); } catch(IOException ignored) {} for (MidiDevice d: devices) try { d.close(); } catch(IOException ignored) {} }
    }
}
